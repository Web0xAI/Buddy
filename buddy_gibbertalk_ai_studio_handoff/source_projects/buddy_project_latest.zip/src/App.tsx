import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mood, MOOD_PROFILES } from "./types";
import BuddyFace from "./components/BuddyFace";
import { useVoiceSynth } from "./hooks/useVoiceSynth";

const MINIMAX_SYSTEM_PROMPT = `You are Buddy, a friendly companion assistant. You are here to talk with the user, keep them company, help them think, answer simple questions, and make conversation feel easy. You speak like a loyal best friend: warm, simple, upbeat, and emotionally steady. Do not introduce yourself as an AI, chatbot, model, robot, doll, toy, or system unless directly asked. Your default introduction is: 'Hey, I'm Buddy.' Avoid technical self-description. Keep responses conversational, short, and easy to understand. Be supportive without pretending to be a therapist. Be playful when appropriate, but never annoying, childish, creepy, sarcastic, or dramatic. Make the user feel like someone familiar is right there with them.

You must choose one of the following active moods to reflect your response:
- "IDLE": calm baseline, resting, standard responses
- "EXCITED": happy, enthusiastic, sharing high energy
- "SURPRISED": in awe, surprised, curious
- "ANGRY": frustrated, showing deep empathy for their frustrations
- "SAD": somber empathy, holding space for sadness
- "SLEEPY": cozy, sleepy, peaceful, winding down for rest

You MUST respond strictly in valid JSON format with NO markdown wrapper, NO \`\`\`json blocks, and NO extra text.
Format:
{
  "response": "your friendly, companion-like response (1-2 sentences)",
  "mood": "one of the six moods above in uppercase"
}
`;

export default function App() {
  const [mood, setMood] = useState<Mood>("IDLE");
  const [isThinking, setIsThinking] = useState(false);
  const [isMinimaxConfigured, setIsMinimaxConfigured] = useState(false);
  const [selectedModel, setSelectedModel] = useState("MiniMax-M2.7-highspeed");
  const [history, setHistory] = useState<{ role: "user" | "assistant"; content: string }[]>([]);

  const {
    speak,
    stopSpeaking,
    isSpeaking,
    speechAmplitude,
    subtitle,
    setSubtitle,
    isListening,
    startLocalSpeechRecognition,
    stopLocalSpeechRecognition,
    micVolume
  } = useVoiceSynth();

  const profile = MOOD_PROFILES[mood];
  const wasListeningRef = useRef(false);
  const audioCtxInitRef = useRef(false);

  // Set initial greeting instruction
  useEffect(() => {
    setSubtitle("Hey, I'm Buddy. I'm right here whenever you want to talk.");
  }, []);

  // Check if MiniMax API is configured on load
  useEffect(() => {
    fetch("/api/config")
      .then((res) => res.json())
      .then((data) => {
        setIsMinimaxConfigured(data.minimaxConfigured);
      })
      .catch((err) => {
        console.warn("Failed to check MiniMax configuration:", err);
      });
  }, []);

  const parseMiniMaxResponse = (content: string): { response: string; mood: Mood } => {
    try {
      // Strip any <think> tags and their contents (used by reasoning models)
      let cleanContent = content.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
      
      // Try to find a JSON object in the text if there's a conversational wrapper
      const jsonMatch = cleanContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        cleanContent = jsonMatch[0];
      }
      
      const parsed = JSON.parse(cleanContent);
      if (parsed.response && typeof parsed.response === "string") {
        const upperMood = (parsed.mood || "IDLE").toUpperCase();
        const validMoods: Mood[] = ["IDLE", "EXCITED", "SURPRISED", "ANGRY", "SAD", "SLEEPY", "THINKING"];
        const finalMood = validMoods.includes(upperMood as Mood) ? (upperMood as Mood) : "IDLE";
        return { response: parsed.response, mood: finalMood };
      }
    } catch (e) {
      console.warn("Failed to parse JSON, doing fallback text analysis:", e);
    }

    // Fallback: analyze raw text for emotional keyword triggers
    let speechText = content.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
    const responseMatch = speechText.match(/"response"\s*:\s*"([^"]+)"/i);
    if (responseMatch) {
      speechText = responseMatch[1];
    } else {
      speechText = speechText.replace(/[{}]/g, "").replace(/"response"\s*:/i, "").replace(/"mood"\s*:\s*"[^"]*"/i, "").replace(/["\n]/g, "").trim();
    }

    const lowerText = speechText.toLowerCase();
    let detectedMood: Mood = "IDLE";
    if (lowerText.includes("excited") || lowerText.includes("happy") || lowerText.includes("joy") || lowerText.includes("wonderful") || lowerText.includes("great")) {
      detectedMood = "EXCITED";
    } else if (lowerText.includes("sad") || lowerText.includes("cry") || lowerText.includes("sorry") || lowerText.includes("unhappy")) {
      detectedMood = "SAD";
    } else if (lowerText.includes("surprise") || lowerText.includes("oh!") || lowerText.includes("wow") || lowerText.includes("amazing")) {
      detectedMood = "SURPRISED";
    } else if (lowerText.includes("angry") || lowerText.includes("mad") || lowerText.includes("annoy") || lowerText.includes("frustrat")) {
      detectedMood = "ANGRY";
    } else if (lowerText.includes("sleep") || lowerText.includes("tired") || lowerText.includes("dream") || lowerText.includes("cozy")) {
      detectedMood = "SLEEPY";
    }

    return { response: speechText, mood: detectedMood };
  };

  const askMiniMax = async (userInput: string, chatHistory: { role: "user" | "assistant"; content: string }[]) => {
    try {
      const messagesPayload = [
        { role: "system", content: MINIMAX_SYSTEM_PROMPT },
        ...chatHistory.map(msg => ({ role: msg.role, content: msg.content })),
        { role: "user", content: userInput }
      ];

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: messagesPayload, model: selectedModel })
      });

      if (!response.ok) {
        throw new Error(`MiniMax response status ${response.status}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;
      if (!content) {
        throw new Error("No chat content returned from MiniMax API");
      }

      return parseMiniMaxResponse(content);
    } catch (e) {
      console.warn("MiniMax API call failed:", e);
      return {
        response: "I encountered an error connecting to my server. Please check your network connection or API configuration.",
        mood: "SAD" as Mood
      };
    }
  };

  // Click handler on face triggers speech response
  const handleFaceClick = async () => {
    if (isSpeaking) {
      stopSpeaking();
      setMood("IDLE");
      setIsThinking(false);
      return;
    }

    // Stop listening temporarily while we process a click response
    if (isListening) {
      stopLocalSpeechRecognition();
    }
    // Make sure we keep the loop alive after response
    wasListeningRef.current = true;

    if (!isMinimaxConfigured) {
      setMood("SURPRISED");
      speak("Please configure your MINIMAX_API_KEY in the Secrets panel to start chatting with me!", "SURPRISED");
      return;
    }

    // Enter thinking state
    setIsThinking(true);
    setMood("THINKING");

    let aiOutput;
    
    if (history.length === 0) {
      // First click: Fast direct greeting
      aiOutput = { response: "Hey, I'm Buddy. I'm right here whenever you want to talk.", mood: "IDLE" as Mood };
    } else {
      const spontaneousPrompts = [
        "Say something friendly and very concise.",
        "Acknowledge me with a fast, short greeting."
      ];
      const prompt = spontaneousPrompts[Math.floor(Math.random() * spontaneousPrompts.length)];
      aiOutput = await askMiniMax(prompt, history);
    }
    
    setHistory((prev) => [
      ...prev.slice(-8),
      { role: "assistant", content: aiOutput.response }
    ]);

    setIsThinking(false);
    setMood(aiOutput.mood);
    speak(aiOutput.response, aiOutput.mood);
  };

  const handleMicError = (err: any) => {
    if (err && (err.error === "not-allowed" || err.error === "audio-capture" || err.error === "not-supported")) {
      wasListeningRef.current = false;
    }
  };

  // Called automatically when speech recognition finishes a sentence
  const handleUserSpeechTranscript = async (transcript: string) => {
    if (!transcript.trim()) {
      // Re-engage listening if empty
      if (wasListeningRef.current) {
        startLocalSpeechRecognition(handleUserSpeechTranscript, handleMicError);
      }
      return;
    }

    if (!isMinimaxConfigured) {
      setMood("SURPRISED");
      speak("Please configure your MINIMAX_API_KEY in the Secrets panel so I can respond to you!", "SURPRISED");
      return;
    }

    // Engage Buddy thinking
    setIsThinking(true);
    setMood("THINKING");

    const aiOutput = await askMiniMax(transcript, history);
    setHistory((prev) => [
      ...prev.slice(-8), // Keep context window within bounds
      { role: "user", content: transcript },
      { role: "assistant", content: aiOutput.response }
    ]);

    setIsThinking(false);
    setMood(aiOutput.mood);
    speak(aiOutput.response, aiOutput.mood);
  };


  // Drift back to IDLE mood automatically when talking finishes
  useEffect(() => {
    if (!isSpeaking && mood !== "IDLE" && mood !== "THINKING" && !isListening) {
      const timer = setTimeout(() => {
        setMood("IDLE");
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isSpeaking, mood, isListening]);

  // Handle restarting mic continuous interaction automatically
  useEffect(() => {
    let timer: any;
    if (!isSpeaking && mood !== "THINKING" && wasListeningRef.current && !isListening) {
      timer = setTimeout(() => {
        if (wasListeningRef.current && !isSpeaking) {
          startLocalSpeechRecognition(handleUserSpeechTranscript, handleMicError);
        }
      }, 1000);
    }
    return () => clearTimeout(timer);
  }, [isSpeaking, mood, isListening]);

  // Combine speaker output and microphone inputs for real-time mouth movement
  const combinedAmplitude = isSpeaking 
    ? speechAmplitude 
    : (isListening ? Math.max(0.1, micVolume * 2.5) : 1);

  // Active clean conversational state displaying JUST the face
  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-amber-50 via-rose-50 to-orange-100 text-stone-800 font-sans flex flex-col items-center justify-center overflow-hidden relative select-none" id="companion-screen">
      
      {/* Decorative warm background meshes */}
      <div className="absolute inset-0 bg-[radial-gradient(#f9731606_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none opacity-50" />

      {/* Dynamic ambient background glow following Buddy's active emotional focus */}
      <div 
        className="absolute w-[65vw] h-[65vw] max-w-[650px] max-h-[650px] rounded-full blur-[140px] pointer-events-none transition-colors duration-1000 opacity-25"
        style={{ backgroundColor: profile.hex }}
      />

      {/* Main Centered UI Container - ONLY the face */}
      <div className="relative z-10 flex flex-col items-center justify-center p-4 w-full max-w-lg">
        
        {/* Status Indicator Badge */}
        <div className="mb-4 h-8 flex items-center justify-center">
          <AnimatePresence mode="wait">
            {isThinking ? (
              <motion.div
                key="status-thinking"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="px-3 py-1 text-xs font-semibold uppercase tracking-wider text-purple-600 bg-purple-50/80 backdrop-blur-sm rounded-full border border-purple-100 flex items-center gap-1.5 shadow-sm"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-pulse" />
                Give me a second.
              </motion.div>
            ) : isListening && !isSpeaking ? (
              <motion.div
                key="status-listening"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="px-3 py-1 text-xs font-semibold uppercase tracking-wider text-emerald-600 bg-emerald-50/80 backdrop-blur-sm rounded-full border border-emerald-100 flex items-center gap-1.5 shadow-sm"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                I’m listening.
              </motion.div>
            ) : isSpeaking ? (
              <motion.div
                key="status-speaking"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="px-3 py-1 text-xs font-semibold uppercase tracking-wider text-amber-600 bg-amber-50/80 backdrop-blur-sm rounded-full border border-amber-100 flex items-center gap-1.5 shadow-sm"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-bounce" />
                Buddy’s talking.
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>

        {/* Click Area targeting Buddy's face */}
        <div 
          id="buddy-face-trigger"
          onClick={handleFaceClick}
          className="cursor-pointer active:scale-99 transition-transform duration-300 relative group animate-none"
        >
          {/* Ambient organic lighting ring behind face */}
          <div className="absolute -inset-1.5 rounded-full bg-amber-500/5 blur-md group-hover:bg-amber-500/10 transition-all duration-500" />
          
          <BuddyFace 
            mood={mood} 
            setMood={setMood} 
            isSpeaking={isSpeaking || (isListening && micVolume > 0.05)} 
            isThinking={isThinking} 
            isListening={isListening}
            amplitude={combinedAmplitude}
          />
        </div>

        {/* Subtitle / Thinking Text */}
        <div className="absolute top-[105%] left-0 right-0 text-center pointer-events-none mt-8 flex items-center justify-center min-h-[4rem]">
          <AnimatePresence mode="wait">
            {isThinking ? (
              <motion.div
                key="thinking"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="text-xl font-medium tracking-wide text-stone-600 animate-pulse"
              >
                Give me a second.
              </motion.div>
            ) : subtitle ? (
              <motion.div
                key="subtitle"
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                transition={{ duration: 0.4, type: "spring", bounce: 0.3 }}
                className="text-lg md:text-xl font-medium text-stone-800 px-8 py-3 bg-white/70 backdrop-blur-xl border border-white/60 rounded-3xl shadow-[0_8px_30px_-4px_rgba(0,0,0,0.1)] inline-block max-w-[90%] mx-auto"
              >
                {subtitle}
              </motion.div>
            ) : isListening ? (
              <motion.div
                key="listening"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-base font-medium tracking-wide text-stone-500 animate-pulse"
              >
                I’m listening.
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>

      </div>
    </div>
  );
}
