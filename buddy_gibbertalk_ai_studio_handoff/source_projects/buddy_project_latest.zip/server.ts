import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API config route to check if MiniMax is configured
  app.get("/api/config", (req, res) => {
    res.json({
      minimaxConfigured: !!process.env.MINIMAX_API_KEY
    });
  });

  // API chat route proxying MiniMax M2.7
  app.post("/api/chat", async (req, res) => {
    const { messages, model = "MiniMax-M2.7" } = req.body;
    const apiKey = process.env.MINIMAX_API_KEY;

    if (!apiKey) {
      return res.status(400).json({
        error: "MINIMAX_API_KEY is not configured on the server. Please add it to your environment variables.",
        fallback: true
      });
    }

    try {
      // Call the OpenAI-compatible MiniMax endpoint
      const response = await fetch("https://api.minimaxi.chat/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: model, // Target MiniMax model
          messages: messages,
          temperature: 0.7,
        })
      });

      if (!response.ok) {
        const errText = await response.text();
        console.error("MiniMax API Error Response:", errText);
        return res.status(response.status).json({
          error: `MiniMax API Error: ${errText || response.statusText}`,
          fallback: true
        });
      }

      const data = await response.json();
      return res.json(data);
    } catch (error: any) {
      console.error("Error communicating with MiniMax API:", error);
      return res.status(500).json({
        error: error.message || "Failed to communicate with MiniMax API",
        fallback: true
      });
    }
  });

  // API tts route proxying MiniMax T2A
  app.post("/api/tts", async (req, res) => {
    const { text, mood } = req.body;
    const apiKey = process.env.MINIMAX_API_KEY;

    if (!apiKey) {
      return res.status(400).json({ error: "MINIMAX_API_KEY is not configured" });
    }

    let speed = 1.0;
    let pitch = 0;
    
    switch (mood) {
      case "EXCITED": speed = 1.15; pitch = 1; break;
      case "SURPRISED": speed = 1.10; pitch = 1; break;
      case "ANGRY": speed = 1.20; pitch = -1; break;
      case "SAD": speed = 0.85; pitch = -1; break;
      case "SLEEPY": speed = 0.75; pitch = -1; break;
      case "THINKING": speed = 0.90; pitch = 0; break;
      default: speed = 1.0; pitch = 0; break;
    }

    try {
      const response = await fetch("https://api.minimaxi.chat/v1/t2a_v2", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: "speech-01-turbo",
          text: text,
          stream: false,
          voice_setting: {
            voice_id: "presenter_male", // male american english-capable voice
            // VOICE DIRECTION FOR MINIMAX:
            // Voice style: "Warm friendly companion voice. Cheerful, clear, loyal, and emotionally steady. Slightly playful but not cartoonish. Natural casual pacing. Gentle 1980s best-friend energy. Friendly enough to feel personal, but not childish, creepy, robotic, corporate, or exaggerated."
            // Avoid: Corporate assistant voice, Announcer voice, Deep narrator voice, Robotic AI voice, Whispery voice, Horror-doll voice, Sarcastic cartoon voice, Babyish toddler voice, Overacted mascot voice.
            speed: speed,
            vol: 1.0,
            pitch: pitch
          },
          audio_setting: {
            sample_rate: 32000,
            bitrate: 128000,
            format: "mp3"
          }
        })
      });

      if (!response.ok) {
        return res.status(response.status).json({ error: await response.text() });
      }

      const data = await response.json();
      if (data.data && data.data.audio) {
        // Convert hex to buffer
        const audioBuffer = Buffer.from(data.data.audio, 'hex');
        res.setHeader('Content-Type', 'audio/mpeg');
        return res.send(audioBuffer);
      } else {
        return res.status(500).json({ error: "No audio data received" });
      }
    } catch (error: any) {
      console.error("Error communicating with MiniMax TTS API:", error);
      return res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
